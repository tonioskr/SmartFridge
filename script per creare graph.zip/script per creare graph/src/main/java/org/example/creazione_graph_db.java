package org.example;


public class creazione_graph_db {
    public static void main(String[] args){
        String user = "neo4j";
        String password = "rootroot";
        Neo4jDBJavaEx es = new Neo4jDBJavaEx("bolt://localhost:7687",user ,password);
        int limit = 100000;
        es.create_Users(limit);
        es.create_all_receipe(limit);
        es.create_follow(1000);
    }
}
