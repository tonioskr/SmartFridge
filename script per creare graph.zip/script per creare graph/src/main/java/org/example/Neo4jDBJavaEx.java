package org.example;

import com.mongodb.client.*;
import com.mongodb.client.model.Projections;
import org.bson.Document;
import org.bson.conversions.*;
import org.neo4j.driver.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import static org.neo4j.driver.Values.parameters;

public class Neo4jDBJavaEx{
    private static  Driver driver;
    Neo4jDBJavaEx(String uri, String user, String password){
        driver = GraphDatabase.driver(uri, AuthTokens.basic(user, password));
    }

    void create_Users(int limit){ //ok
        String uri = "mongodb://localhost:27017";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("SmartFridge");
        MongoCollection<Document> collection = database.getCollection("User");

        MongoCursor<Document> cursor =  collection.find().iterator();

        ArrayList<Document> results = collection.find().into(new ArrayList<>());

        int i =0 ;
        for(Document c: results){
            try (Session session = driver.session()) {
                //merge cause maybe the user may not be present
                session.writeTransaction(tx -> {
                    tx.run("MERGE (a:User {name: $name, id: $id, country: $country})",
                            parameters("name", c.getString("username"), "id", c.get("_id").toString(),"country",c.getString("country"))).consume();
                    return 1;
                });
            }
            System.out.println("" + i + " utente");
            i++;
            //IF PER CREARE SOLO 100 RICETTE

            if(limit !=0 && i==limit){
                break;
            }
        }
    }

    void create_all_receipe(int limit) { //ok
        try{
        HashMap<String, String> id_username = retrive_id_user();
        String uri = "mongodb://localhost:27017";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("SmartFridge");
        MongoCollection<Document> collection = database.getCollection("Recipe");


        ArrayList<Document> results = collection.find().into(new ArrayList<>());
        int i=0;
        for (Document c : results) {
            if(limit != 0  && id_username.get(c.getString("Author"))==null ){
                i--;
                continue;
            }
            int review_count = c.getInteger("ReviewCount");
            String totalTime = c.getString("TotalTime");
            create_recipe(
                    c.getString("RecipeName"),
                    c.get("_id").toString(),
                    review_count,
                    totalTime,
                    id_username.get(c.getString("Author"))
            );

            System.out.println("siamo all'ricetta" + i++);
            if(limit !=0 && i==limit){
                break;
            }
        }
        }catch (Exception e){
            System.err.println(e);
        }

    }


    public HashMap<String,String> retrive_id_user(){
        HashMap<String,String> associazione_id_username = new HashMap<>();
        String name;
        int id;

        String uri = "mongodb://localhost:27017";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("SmartFridge");
        MongoCollection<Document> collection = database.getCollection("User");

        Bson projectionFields = Projections.fields(
                Projections.include("username"),
                Projections.include("_id"));

        ArrayList<Document> results = collection.find().projection(projectionFields).into(new ArrayList<>());
        for(Document c: results){
            associazione_id_username.put(c.getString("username"),c.get("_id").toString());
        }
        return associazione_id_username;
    }

    void create_recipe(String name, String id_receipe,int review_count, String totalTime, String id_user ) {
        try (Session session = driver.session()) {
            //create a recipe
            session.writeTransaction(tx -> {

                tx.run("MERGE (a:Recipe {name: $name, id: $id,review_count: $review_count, totalTime: $totalTime }) ",
                        parameters(
                                "name", name,
                                "id", id_receipe,
                                "review_count",review_count,
                                "totalTime", totalTime
                        )
                ).consume();
                //create a relathionship between the user and the receipe

                tx.run("MATCH (a:User) WHERE a.id = $id " +
                                "MATCH (b:Recipe) WHERE b.id = $id1 " +
                                "CREATE (a)-[:SHARE]->(b)",
                        parameters("id", id_user, "id1", id_receipe)).consume();

                return 1;
            });
        }
    }


    public void create_follow(int limit) {
        ArrayList<String> associazione_id = new ArrayList<>();

        String uri = "mongodb://localhost:27017";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("SmartFridge");
        MongoCollection<Document> collection = database.getCollection("User");

        Bson projectionFields = Projections.fields(
                Projections.include("_id"));

        ArrayList<Document> results = collection.find().projection(projectionFields).into(new ArrayList<>());
        for(Document c: results){
            associazione_id.add(c.get("_id").toString());
        }

        //associazione id fatta creata

        int counter = 0;
        //ora creare relathionship
        for(String c: associazione_id){
            String user1 = c;
            int user2 = 0;
            int rand = get_random_number(40);
            while(rand>=0){

                user2 = get_random_number(30000);
                follow_a_user(user1,associazione_id.get(user2));
                rand--;
            }

            System.out.println(counter++);
            if(counter==20000 || counter == limit)break;
        }

    }
    public int get_random_number(int limit){
        Random rand = new Random();

        int n = rand.nextInt(limit);
        n += 1;
        return n;
    }
    public static void follow_a_user(String id_user1, String id_user2){

        try (Session session = driver.session()) {

            session.writeTransaction(tx -> {
                tx.run( "MATCH (a:User) WHERE a.id = $id1 " +
                                "MATCH (b:User) WHERE b.id = $id2 " +
                                "CREATE (a)-[:FOLLOW]->(b)",
                        parameters("id1", id_user1, "id2", id_user2)).consume();
                System.out.println("I due utenti si seguono");
                return 1;
            });
        }
    }
}


